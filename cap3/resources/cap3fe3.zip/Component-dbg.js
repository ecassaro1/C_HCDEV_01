sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("cap3fe3.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);